using namespace std;
#include <bits/stdc++.h>
#define pb push_back
#define ll long long
#define ull unsigned long long 
#define FF first
#define SS second
#define MOD 1000000007

typedef vector<ll> vll;


int main()
{
	ios_base::sync_with_stdio(false);
	int t;
	cin>>t;
	for(int j=0;j<t;j++)
	{
		string s;
		cin>>s;
		int k;cin>>k;
		ll ans = 0;
		int last_index = -1;
		int flip=0;
		for(int i=0;i<s.size();i++)
		{
			//cout<<"ans = "<<ans<<" last = "<<last_index<<" s[i] "<<s[i]<<"flip= "<<flip<<endl;

			if(s[i]=='-')
			{
				if(last_index>=i)
				{	
					if(flip%2==0)
					{
						ans++;
						flip=1;
						last_index= i+k-1;
					}
				}
				else
				{
					ans++;
					flip=1;
					last_index= i+k-1;
				}
			}
			else if(s[i]=='+')
			{
				if(last_index>=i)
				{
					if(!flip)
					{
						ans++;
						last_index = i+k-1;
						flip=0;
					}
				}
				else
				{
					flip= 0;
				}
				
			}	
			//cout<<"ans = "<<ans<<" last = "<<last_index<<" s[i] "<<s[i]<<"flip= "<<flip<<endl;
			//cout<<"--------------------------------------------------"<<endl;
		}
		//cout<<"ans = "<<ans<<endl;
		//cout<<"last~!!!= "<<last_index<<endl;
		if(last_index<=s.size()+1 || ans==0)
		{
			cout<<"Case #"<<j+1<<": "<<ans<<endl;
		}
		else
		{
			cout<<"Case #"<<j+1<<": "<<"IMPOSSIBLE"<<endl;	
		}
	}
}
